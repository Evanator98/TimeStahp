﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Thursday December 13, 2018
 * This script is to spawn in Mystical Boom Boom Blobs during level 3
 * */
public class MBBBSpawn : MonoBehaviour {

    public float timer = 10.0f;
    public GameObject player, mBBB, temp;

    private void Start()
    {
        player = GameObject.Find("Player");
    }


    private void Update()
    {
        timer = timer - Time.deltaTime;

        if (timer <= 0)
        {
            temp = Instantiate(mBBB);
            temp.transform.position = transform.position;
            timer = Random.Range(5.0f, 10.0f);
        }


    }

    private void LateUpdate()
    {
        transform.position = player.transform.position + new Vector3(25, 10, 0);
    }
}
