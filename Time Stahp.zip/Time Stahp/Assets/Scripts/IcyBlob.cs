﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/**
 * Evan Sinasac - 104571345
 * Monday December 10, 2018
 * This script is to describe the behaviour of the Icy Blob enemy
 * */
public class IcyBlob : MonoBehaviour {

    public float timer = 6.0f, wait = 0.5f;
    public GameObject projectile, temp;
    public GameObject player;
    public bool jump = true;

	// Use this for initialization
	void Start () {
        player = GameObject.Find("Player");
    }
	
	
	void FixedUpdate () {

        timer = timer - Time.deltaTime;

        if (timer <= 0)
        {
            if (jump)
            {
                GetComponent<Rigidbody>().AddForce(0, 5f, 0, ForceMode.Impulse);
                jump = false;
            }
            wait = wait - Time.deltaTime;
            if (wait <= 0)
            {
                if (player.transform.position.x < transform.position.x)
                {
                    temp = Instantiate(projectile, new Vector3(transform.position.x - 1.25f, transform.position.y, 0), Quaternion.identity);
                    temp.GetComponent<Rigidbody>().AddForce(-10f, 3f, 0f, ForceMode.Impulse);
                }
                else if (player.transform.position.x > transform.position.x)
                {
                    temp = Instantiate(projectile, new Vector3(transform.position.x + 1.25f, transform.position.y, 0), Quaternion.identity);
                    temp.GetComponent<Rigidbody>().AddForce(10f, 3f, 0f, ForceMode.Impulse);
                }
                timer = 6.0f;
                wait = 0.5f;
                jump = true;
            }
        }

	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == 12)
        {
            gameObject.transform.position = transform.position - new Vector3(2, 0, 0);
            Destroy(gameObject);
        }
    }

}
