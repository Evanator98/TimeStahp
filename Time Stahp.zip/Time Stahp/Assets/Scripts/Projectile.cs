﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/**
 * Evan Sinasac - 104571345
 * Monday December 10, 2018
 * This script is to describe the behaviour of the projectile
 * */
public class Projectile : MonoBehaviour {

    public float timer = 5.0f;

    private void FixedUpdate()
    {
        timer = timer - Time.deltaTime;

        if (timer <= 0)
        {
            Destroy(gameObject);
        }
    }

}
