﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/**
 * Evan Sinasac - 104571345
 * Sunday December 9, 2018
 * This script is to describe the behaviour of the Mystical Boom Boom Blob enemy
 * */
public class MBBB : MonoBehaviour {

    public GameObject player;
    public CapsuleCollider col;
    public ParticleSystem exp;
    public float timer = 5.0f, timer2 = 1.0f;
    bool tp = false;

    // Use this for initialization
    void Start () {
        player = GameObject.Find("Player");
        col = gameObject.GetComponent<CapsuleCollider>();
    }
	

	void FixedUpdate () {

        timer = timer - Time.deltaTime;
        

        if (timer <= 0)
        {
            gameObject.transform.position = player.transform.position + new Vector3(4f, 0f, 0);
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
            timer = 5.0f;
            col.enabled = false;
            tp = true;
        }

        if (tp)
        {
            timer2 = timer2 - Time.deltaTime;
            if (timer2 <= 0)
            {
                exp.Play();
                tp = false;
                timer2 = 1.0f;
                col.enabled = true;
            }
        }

	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == 12)
        {
            gameObject.transform.position = transform.position - new Vector3(2, 0, 0);
        }
    }

}
