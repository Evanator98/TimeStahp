﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Thursday December 13, 2018
 * This script is to describe the behaviour of the elevator platform
 * */
public class UpAndDown : MonoBehaviour {

    private bool up = true;
    private float speed = 3.0f;

    private void Update()
    {
        if (up)
            transform.Translate(Vector3.up * speed * Time.deltaTime);
        else
            transform.Translate(Vector3.down * speed * Time.deltaTime);

        if (transform.position.y >= 5)
            up = false;
        if (transform.position.y <= -2)
            up = true;

    }

}
