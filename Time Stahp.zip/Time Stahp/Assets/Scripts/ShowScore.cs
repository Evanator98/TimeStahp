﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/**
 * Evan Sinasac - 104571345
 * Thursday December 13, 2018
 * This script is used to show the number of collectables that have been collected.
 * */
public class ShowScore : MonoBehaviour {

    public Text collected;
    
    // Update is called once per frame
    void Update () {
        collected.text = PlayerPrefs.GetInt("Collectables").ToString();
	}
}
