﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Mostly Wednesday December 12, 2018
 * This script is used on the main camera of the game, it follows the player but does not move left
 * */
public class FollowPlayer : MonoBehaviour {

    public GameObject playerCharacter;
    public Vector3 lastPos, playerPos, difference;

    
	void Start () {
        // offset = transform.position - playerCharacter.transform.position;
        lastPos = playerCharacter.transform.position + new Vector3(5, 2, -10);
        playerPos = playerCharacter.transform.position;
        difference = transform.position - playerPos;
	}


    private void LateUpdate() {
        // transform.position = playerCharacter.transform.position + offset;
        // transform.position = FindObjectOfType<Player>().transform.position + new Vector3(1, 10, 0);
        //transform.position = playerCharacter.transform.position + new Vector3(0, 2, -10);
        if (Input.GetAxis("Horizontal") <= 0)
        {
            transform.position = lastPos;
        } else
        {
            if (transform.position.x - playerPos.x <= difference.x)
            {
                transform.position = playerCharacter.transform.position + new Vector3(5, 2, -10);
                lastPos = transform.position;
            }
            
        }
        

        playerPos = playerCharacter.transform.position;
    }
}
