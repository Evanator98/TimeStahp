﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/**
 * Evan Sinasac - 104571345
 * Thursday December 6, 2018
 * This script is to describe the behaviour of the Basic Blob enemy
 * */
public class BasicBlob : MonoBehaviour {

    public float timer = 2.0f;
    public bool dirRight = false, squish = true;
    public float xPos;
    public float speed = 2f;

    private Rigidbody rb;


    private void Start()
    {
        xPos = transform.position.x;
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate () {

        timer = timer - Time.deltaTime;

        if (timer <= 0)
        {

            if (dirRight)
            {
                rb.AddForce(new Vector3(0.5f, 0.5f, 0) * speed, ForceMode.Impulse);
            } else
            {
                rb.AddForce(new Vector3(-0.5f, 0.5f, 0) * speed, ForceMode.Impulse);
            } //end of if (dirRight) else

            timer = 3.0f;

        } else
        {

            if (squish)
            {
                transform.localScale = transform.localScale - new Vector3(0, 0.05f, 0);
            }
            else
            {
                transform.localScale += new Vector3(0, 0.05f, 0);
            } //end of if (squish) else

          } //end of if (timer) else


        if (transform.localScale.y > 2.0f)
            squish = true;
        if (transform.localScale.y < 1.0f)
            squish = false;
        if (transform.position.x < (xPos - 4.0f))
        {
            dirRight = true;
        }
        if (transform.position.x > xPos)
        {
            dirRight = false;
        }


    } //end of FixedUpdate

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == 12)
        {
            gameObject.transform.position = transform.position - new Vector3(2, 0, 0);
            Destroy(gameObject);
        }
    }

} //end of BasicBlob
