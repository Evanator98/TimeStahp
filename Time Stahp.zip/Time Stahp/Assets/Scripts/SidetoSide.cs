﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Thursday December 13, 2018
 * This script is to describe the behaviour of the WonkaElevator platform
 * */
public class SidetoSide : MonoBehaviour {

    private bool right = true, begin = true;
    private float speed = 3.0f, startX;


    private void Update()
    {
        if (begin)
        {
            startX = transform.position.x;
            begin = false;
        }

        if (right)
            transform.Translate(Vector3.right * speed * Time.deltaTime);
        else
            transform.Translate(Vector3.left * speed * Time.deltaTime);

        if (transform.position.x >= startX + 5)
            right = false;
        if (transform.position.x <= startX - 2)
            right = true;
    }

}
