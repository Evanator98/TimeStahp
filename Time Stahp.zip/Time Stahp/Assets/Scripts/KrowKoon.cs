﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Sunday December 9, 2018
 * This script is to describe the behaviour of the Krow Koon enemy
 * */
public class KrowKoon : MonoBehaviour {

    public GameObject player;
    Vector3 heading;


    private void Start()
    {
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void FixedUpdate () {

        heading = player.transform.position - gameObject.transform.position;
        var distance = heading.magnitude;
        var direction = heading / distance / 5f;

        transform.Translate(direction);

	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == 12)
        {
            gameObject.transform.position = transform.position - new Vector3(2, 0, 0);
            Destroy(gameObject);
        }
    }
}
