﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Matthew Pizzo - 104613016
 * Thursday December 9, 2018
 * Adds 3 health to the players existing life on collision (Max at 6)
 * */
public class HealthPU : MonoBehaviour {

    public GameObject pickupEffect;
    public GameObject effect;
    public GameObject player;
    public Renderer playerRenderer;
    public Material powMaterial;
    public Material ogMaterial;
    public float duration;
    public int boost;

    private void Start()
    {
        player = GameObject.Find("Player");
        playerRenderer = player.GetComponentInChildren<Renderer>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine( Pickup());
        }
    }

    IEnumerator Pickup()
    {
        effect = Instantiate(pickupEffect, transform.position, transform.rotation);

        
        playerRenderer.material = powMaterial;
        ogMaterial = playerRenderer.material;

        if (player.GetComponent<MovePlayer>().health + boost >= 6)
        {
            player.GetComponent<MovePlayer>().health = 6;
        } else
        {
            player.GetComponent<MovePlayer>().health += boost;
            player.GetComponent<MovePlayer>().healthChange = true;
        }
        
        GetComponent<MeshRenderer>().enabled = false;
        GetComponent<Collider>().enabled = false;

        yield return new WaitForSeconds(duration);

        //player.GetComponent<MovePlayer>().health -= boost;
        playerRenderer.material = ogMaterial;

        Destroy(effect);
        Destroy(gameObject);
    }
}
