﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Matthew Pizzo - 104613016
 * Thursday December 8, 2018
 * Activates the Electric Field on collection, causes enemies to be pushed away upon entering the collider.
 * Lasts for a set duration 
 * */
public class EField : MonoBehaviour {

    public GameObject pickupEffect;
    public GameObject effect;
    public Collider playerCollider;
    public GameObject player;
    public Renderer playerRenderer;
    public Material powMaterial;
    public Material ogMaterial;
    public float duration;

    void Start()
    {
        player = GameObject.Find("Player");
        playerRenderer = player.GetComponentInChildren<Renderer>();
        playerCollider = player.GetComponent<Collider>();
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine( Pickup());
        }
    }

    IEnumerator Pickup()
    {
        effect = Instantiate(pickupEffect, transform.position, transform.rotation);

        Debug.Log("Collider: " + playerCollider.enabled);

        ogMaterial = playerRenderer.material;
        playerRenderer.material = powMaterial;

        playerCollider.enabled = true;
        player.GetComponent<MovePlayer>().Eshield = true;

        Debug.Log("Collider: " + playerCollider.enabled);

        GetComponent<MeshRenderer>().enabled = false;
        GetComponent<Collider>().enabled = false;

        yield return new WaitForSeconds(duration);

        playerRenderer.material = ogMaterial;
        player.GetComponent<MovePlayer>().Eshield = false;
        playerCollider.enabled = false;

        Destroy(effect);
        Destroy(gameObject);
    }
}
