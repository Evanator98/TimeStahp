﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Matthew Pizzo - 104613016
 * Thursday December 9, 2018
 * Makes a raycast that destroy's the hit objects 
 * */
public class LaserPower : MonoBehaviour {

    public Transform laserOrigin;
    public bool laserActive = false;
    public LayerMask maskEnemies = -1;
    public Vector3 mouseDown;
    public ParticleSystem laserEffect;
    

    // Update is called once per frame
    void Update()
    {
        if (laserActive == true) {
            if (Input.GetMouseButtonDown(0))
            {
                
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                
                if (Physics.Raycast(ray, out hit, float.PositiveInfinity, maskEnemies))
                {
                    
                    
                    Debug.DrawRay(ray.origin, ray.direction * 50f, Color.green, 60f);
                    mouseDown = hit.point;
                    mouseDown.z = 0;
                    Debug.Log(mouseDown);
                    Ray ray2 = new Ray(laserOrigin.position , mouseDown);

                    laserEffect.Play();
                    RaycastHit hit2;
                    laserEffect.transform.position = ray2.origin;
                    Debug.DrawRay(ray2.origin, ray2.direction * 50f, Color.red, 60f);
                    
                    laserEffect.transform.position = ray2.direction;

                    if (Physics.Raycast(ray2, out hit2, float.PositiveInfinity, maskEnemies))
                    {
                        Destroy(hit2.collider.gameObject);
                        
                    }
                    
                }
            }
            
        }

    }

}
