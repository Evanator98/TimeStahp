﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Matthew Pizzo - 104613016
 * Thursday December 9, 2018
 * Activates the laser power-up when collected
 * */
public class Laser : MonoBehaviour {

    public GameObject pickupEffect;
    public GameObject effect;
    private GameObject player;
    public Renderer playerRenderer;
    public Material powMaterial;
    public Material ogMaterial;
    public float duration;

    private void Start()
    {
        player = GameObject.Find("Player");
        playerRenderer = player.GetComponentInChildren<Renderer>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine(Pickup());
        }
    }

    IEnumerator Pickup()
    {
        effect = Instantiate(pickupEffect, transform.position, transform.rotation);

        ogMaterial = playerRenderer.material;
        playerRenderer.material = powMaterial;
        GetComponent<MeshRenderer>().enabled = false;
        GetComponent<Collider>().enabled = false;

        player.GetComponent<LaserPower>().laserActive = true;

        yield return new WaitForSeconds(duration);

        player.GetComponent<LaserPower>().laserActive = false;
        playerRenderer.material = ogMaterial;
        Destroy(effect);
        Destroy(gameObject);
       
    }
}
