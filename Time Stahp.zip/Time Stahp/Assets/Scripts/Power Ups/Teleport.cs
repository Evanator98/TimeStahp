﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Matthew Pizzo - 104613016
 * Thursday December 9, 2018
 * Toggles the Teleport power-up lasts for a set duration
 * */
public class Teleport : MonoBehaviour {

    public GameObject player;
    public GameObject pickupEffect;
    public GameObject effect;
    public int charges;

    void Start()
    {
        player = GameObject.Find("Player");
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Pickup();
        }
    }

    void Pickup()
    {
        effect = Instantiate(pickupEffect, transform.position, transform.rotation);

        player.GetComponent<TeleportPower>().Teleport = true;
        player.GetComponent<TeleportPower>().tpCount = charges;

        Destroy(effect);
        Destroy(gameObject);
    }

   
}
