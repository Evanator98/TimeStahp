﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/**
 * Matthew Pizzo - 104613016
 * Thursday December 9, 2018
 * Lets the user click on the screen and move to the selected location.
 * After using the player can jump again and is invulnerable for two seconds
 * */
public class TeleportPower : MonoBehaviour {

    public bool Teleport = false, colorChange = false;
    public int tpCount = -1;
    public Vector3 mouseDown;
    public LayerMask mask;
    public float timer_ = 2;
    public Material powMaterial;
    public Material ogMaterial;
    public Text teleports;


    // Update is called once per frame
    void Update () {

        if (Teleport == true && tpCount >= 0)
        {
            colorChange = true;
            GetComponentInChildren<Renderer>().material = powMaterial;
            teleports.color = new Color(50f / 255f, 50 / 255f, 50 / 255f, 1f);
            teleports.text = "Teleports Remaining: " + tpCount.ToString();

            if (Input.GetMouseButtonDown(0))
            {

                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;

                if (Physics.Raycast(ray, out hit, float.PositiveInfinity, mask))
                {

                    Debug.DrawRay(ray.origin, ray.direction * 50f, Color.green, 60f);
                    mouseDown = hit.point;
                    mouseDown.z = 0;
                    tpCount--;
                    Debug.Log(Input.mousePosition);

                    GetComponent<MovePlayer>().doubleJ = false;
                    transform.position = mouseDown;

                    timer_ = timer_ - Time.deltaTime;
                    
                    
                    if(timer_ <= 0)
                    {
                        GetComponent<MovePlayer>().invulnerable = false;
                    } else
                    {
                        GetComponent<MovePlayer>().invulnerable = true;
                    }
                }
                
            }

        }else if(colorChange && tpCount <= 0)
        {
            Teleport = false;
            colorChange = false;
            GetComponentInChildren<Renderer>().material = ogMaterial;
            teleports.color = new Color(50f / 255f, 50 / 255f, 50 / 255f, 0f);

        }

    }
}
