﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/**
 * Evan Sinasac - 104571345
 * Monday December 10, 2018
 * This script is to describe the behaviour of the Charging Blob enemy
 * */
public class ChargingBlob : MonoBehaviour {

    public GameObject player;
    public ParticleSystem boom;
    private float speed = -0.1f;

    // Use this for initialization
    void Start () {
        player = GameObject.Find("Player");
    }
	
	// Update is called once per frame
	void Update () {
		


        if (transform.position.x - player.transform.position.x <= 20 && transform.position.x - player.transform.position.x > 0)
        {
            transform.Translate(speed, 0, 0);
            speed = speed - 0.0001f;
        }

        if (transform.position.x - player.transform.position.x < -5)
        {
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
            transform.localScale = transform.localScale - new Vector3(1, 1, 1);
            Instantiate(boom, transform.position, Quaternion.identity);
            Destroy(gameObject);            
            boom.Play();
        }

	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == 12)
        {
            gameObject.transform.position = transform.position - new Vector3(2, 0, 0);
            Destroy(gameObject);
        }
    }
}
