﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/**
 * Evan Sinasac - 104571345
 * Wednesday December 12, 2018
 * This script is used to control changing scenes through out the game
 * */
public class SceneChange : MonoBehaviour {
    

    public void Quit ()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void goToLevelOne ()
    {
        SceneManager.LoadScene("LevelOne");
    }

    public void goToLevelTwo()
    {
        SceneManager.LoadScene("LevelTwo");
    }

    public void goToLevelThree()
    {
        SceneManager.LoadScene("LevelThree");
    }

    public void gameDescription ()
    {
        SceneManager.LoadScene("GameDescription");
    }

    public void mainMenu ()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void exit ()
    {
        //Quit is ignored in the editor but otherwise this would close the game
        Application.Quit();
    }

    public void test ()
    {
        SceneManager.LoadScene("sandbox");
    }

}
