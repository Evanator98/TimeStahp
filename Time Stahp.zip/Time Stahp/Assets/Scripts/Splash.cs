﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/**
 * Matthew Pizzo - 104613016
 * Thursday December 13, 2018
 * Has the splash screen with the game logo stay on 
 * screen for a time before sending the user to the main menu
 * */
public class Splash : MonoBehaviour {

    public float duration;

    private void Awake()
    {
        PlayerPrefs.SetInt("Collectables", 0);
    }

    public void Update()
    {
        if (duration < 0)
        {
            SceneManager.LoadScene("MainMenu");

        }
        else
        {
            duration = duration - Time.deltaTime;
            
        }
    }

  
}
