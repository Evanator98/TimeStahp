﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Thursday December 13, 2018
 * This script is so that the background may follow the camera
 * */
public class Background : MonoBehaviour {

	// Update is called once per frame
	void FixedUpdate () {

        transform.position = Camera.main.transform.position + new Vector3(3, 0, 15);

	}
}
