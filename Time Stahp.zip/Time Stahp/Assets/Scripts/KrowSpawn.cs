﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Thursday December 13, 2018
 * This script is to spawn in Krows during levels 1 and 3
 * */
public class KrowSpawn : MonoBehaviour {

    public float timer = 15.0f;
    public GameObject player, krow, temp;

    private void Start()
    {
        player = GameObject.Find("Player");
    }


    private void Update()
    {
        timer = timer - Time.deltaTime;

        if (timer <= 0)
        {
            temp = Instantiate(krow);
            temp.transform.position = transform.position;
            timer = Random.Range(5.0f, 20.0f);
        }

        
    }

    private void LateUpdate()
    {
        transform.position = player.transform.position + new Vector3(25, 10, 0);
    }

}
