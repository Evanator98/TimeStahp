﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Wednesday December 12, 2018
 * This script is used to pause and resume the gameplay
 * */
public class PauseScript : MonoBehaviour {
    
    public GameObject pauseUI;
    public GameObject otherUI;
    
    public void Pause ()
    {
        pauseUI.SetActive(true);
        Time.timeScale = 0f;
    }

    public void Resume ()
    {
        pauseUI.SetActive(false);
        Time.timeScale = 1f;
    }

    /**
     * Added for changing the screen in the GameDescription scene
     * Added by Evan Sinasac
     * December 13, 2018
     * */
    public void controls ()
    {
        otherUI.SetActive(true);
        pauseUI.SetActive(false);
    }

    public void enemies ()
    {
        otherUI.SetActive(false);
        pauseUI.SetActive(true);
    }
}
