﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Thursday December 13, 2018
 * This script is to procedurlly generate level three
 * */
public class LevelThree : MonoBehaviour {

    public Vector3 distance;
    public GameObject endZone;
    public GameObject collectable;
    public GameObject[] powerups;
    public GameObject[] enemies;
    public GameObject[] platforms;
    public GameObject player, enemy, powerUp;
    private GameObject currentPlatform, previousPlatform;
    public int platform, spawnedIn = 0;
    public int randomChance, whichOne;

    private void Start()
    {
        player = GameObject.Find("Player");
        currentPlatform = GameObject.Find("StartPlatform");
    }

    // Update is called once per frame
    void Update()
    {

        if (player.transform.position.x > currentPlatform.transform.position.x)
        {
            if (previousPlatform != null)
                Destroy(previousPlatform);


            platform = Random.Range(0, 5);
            var newPlatform = Instantiate(platforms[platform]) as GameObject;

            newPlatform.transform.position = currentPlatform.transform.position + distance + new Vector3 (0, Random.Range(-2, 3), 0);

            newPlatform.GetComponent<Renderer>().material.color = new Color(Random.Range(0, 1.1f), Random.Range(0, 1.1f), Random.Range(0, 1.1f), Random.Range(0, 1.1f));

            if (platform != 3 && platform != 4)
            {
                randomChance = Random.Range(0, 21);

                if (randomChance >= 17)
                {

                    whichOne = Random.Range(0, 5);
                    powerUp = Instantiate(powerups[whichOne]);
                    powerUp.transform.position = newPlatform.transform.position + new Vector3(0, 2, 0);
                }
                else if (randomChance >= 10)
                {
                    whichOne = Random.Range(0, 3);
                    enemy = Instantiate(enemies[whichOne]);
                    enemy.transform.position = newPlatform.transform.position + new Vector3(2, 2, 0);
                }
                else if (randomChance >= 5)
                {
                    powerUp = Instantiate(collectable);
                    powerUp.transform.position = newPlatform.transform.position + new Vector3(0, 2, 0);
                }

                //var plat = newPlatform.GetComponent<Platform>();
                spawnedIn++;
            }
            previousPlatform = currentPlatform;
            currentPlatform = newPlatform;

            if (spawnedIn >= 10)
            {
                whichOne = Random.Range(0, 20);
                if (whichOne >= 16)
                {
                    powerUp = Instantiate(endZone);
                    powerUp.transform.position = newPlatform.transform.position + new Vector3(5, 5, 0);
                }
            }
        }

    }
}
