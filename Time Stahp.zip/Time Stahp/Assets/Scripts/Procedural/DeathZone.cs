﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/**
 * Matthew Pizzo - 104613016
 * Thursday December 9, 2018
 * Makes the Death Zone send the player back to the menu and 
 * resets the collectable counter upon triggering the collider
 * */
public class DeathZone : MonoBehaviour {

    public GameObject player;
    
    // Use this for initialization
    void Start()
    {
        player = GameObject.Find("Player");
        
    }

    private void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.layer == 10)
        {
            PlayerPrefs.SetInt("Collectables", 0);
            SceneManager.LoadScene("MainMenu");

        }
    }
}
