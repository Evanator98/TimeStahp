﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * Evan Sinasac - 104571345
 * Thursday December 13, 2018
 * This is a testing script we used to determine how we are going to do the procedural generation of the levels
 * */
public class Generation : MonoBehaviour {

    public Vector3 distance;
    public GameObject endZone;
    public GameObject collectable;
    public GameObject[] powerups;
    public GameObject[] enemies;
    public GameObject[] platforms;
    public GameObject player;
    private GameObject currentPlatform, previousPlatform, newestPlatform;

    private void Start()
    {
        player = GameObject.Find("Player");
        currentPlatform = GameObject.Find("StartPlatform");
    }

    // Update is called once per frame
    void Update () {
		
        if (player.transform.position.x > currentPlatform.transform.position.x)
        {
            if (previousPlatform != null)
                Destroy(previousPlatform);

            var newPlatform = Instantiate(platforms[0]) as GameObject;

            newPlatform.transform.position = currentPlatform.transform.position + distance;

            newPlatform.GetComponent<Renderer>().material.color = new Color(Random.Range(0, 256), Random.Range(0, 256), Random.Range(0, 256));

            //var plat = newPlatform.GetComponent<Platform>();

            previousPlatform = currentPlatform;
            currentPlatform = newPlatform;
        }

	}
}
