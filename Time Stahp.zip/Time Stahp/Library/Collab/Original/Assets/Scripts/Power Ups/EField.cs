﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EField : MonoBehaviour {

    public GameObject pickupEffect;
    public GameObject effect;
    public Collider playerCollider;
    public GameObject player;
    public float duration;

    private void Start()
    {
        player = GameObject.Find("Player");
        playerCollider = player.GetComponent<SphereCollider>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine( Pickup());
        }
    }

    IEnumerator Pickup()
    {
        effect = Instantiate(pickupEffect, transform.position, transform.rotation);

        Debug.Log("Collider: " + playerCollider.enabled);

        playerCollider.enabled = true;
        player.GetComponent<MovePlayer>().Eshield = true;

        Debug.Log("Collider: " + playerCollider.enabled);

        GetComponent<MeshRenderer>().enabled = false;
        GetComponent<Collider>().enabled = false;

        yield return new WaitForSeconds(duration);

        player.GetComponent<MovePlayer>().Eshield = false;
        playerCollider.enabled = false;

        Destroy(effect);
        Destroy(gameObject);
    }
}
