﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/**
 * Evan Sinasac - 104571345
 * Thursday December 6, 2018
 * This script is to describe the behaviour of the Player Character
 * */
public class MovePlayer : MonoBehaviour {

    private Rigidbody rb;
    private float speed = 10f;
    public bool isSafe = false;
   // private float maxVelocity = 20f;
    public bool jump = true, doubleJ = false;
    public int health = 6;
    public bool invulnerable = false;
    public bool Fshield  = false;
    public bool Eshield = false;
    public bool healthChange = false;
    public GameObject life, life2, life3, life4, life5, life6;
    public int enemiesKilled = 0;
    public Text enemies, collected;

    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody>();


	}

    /**
     * Double Jump
     * Added by Evan Sinasac, Thursday December 6, 2018
     * */
    void Update () {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (jump)
            {
                rb.AddForce(new Vector3(0, 3, 0) * speed * 12.0f);
                doubleJ = true;
                jump = false;
            } else
            {
                if (doubleJ)
                {
                    doubleJ = false;
                    rb.AddForce(new Vector3(0, 3, 0) * speed * 12.0f);
                }
            }
            
        }

        
    }

    /**
     * Movement of the Player Character
     * Added by Evan Sinasac, Thursday December 6, 2018
     * */
    private void FixedUpdate() {
        
            var x = Input.GetAxis("Horizontal") * Time.deltaTime * 15.0f;
           // var z = Input.GetAxis("Vertical") * Time.deltaTime * 3.0f;

           // transform.Rotate(0, x, 0);
            transform.Translate(x, 0, 0);

        /* if (Input.GetKey(KeyCode.LeftArrow)) {
             //rb.AddForce (new Vector3(-1, 0, 0) * speed);
             transform.position = new Vector3(transform.position.x - 1, transform.position.y, 0);
         }
         if (Input.GetKey(KeyCode.RightArrow)) {
           //  rb.AddForce (new Vector3(1, 0, 0) * speed);
             transform.position = new Vector3(transform.position.x + 1, transform.position.y, 0);
         }
       //  if (Input.GetKey(KeyCode.UpArrow)) {
      //       rb.AddForce (new Vector3(0, 0, 1) * speed);
      //   }
       //  if (Input.GetKey(KeyCode.DownArrow)) {
      //       rb.AddForce (new Vector3(0, 0, -1) * speed);
       //  }
         if (rb.velocity.magnitude >= maxVelocity) {
             Vector3 v = rb.velocity.normalized * maxVelocity;
             rb.velocity = v;
         }*/

        if(Input.GetKey(KeyCode.LeftControl))
        {
            transform.Translate(x, 0, 0);
        }

        enemies.text = enemiesKilled.ToString();
        collected.text = PlayerPrefs.GetInt("Collectables").ToString();
        
    }

    /**
     * Use LateUpdate to change the number of displayed hearts in the GUI
     * Added by Evan Sinasac, Wednesday December 12, 2018
     * */
    private void LateUpdate()
    {
        if (healthChange)
        {
            switch (health)
            {
                case 0:
                    PlayerPrefs.SetInt("Collectables", 0);
                    SceneManager.LoadScene("MainMenu");
                    break;
                case 1:
                    life.SetActive(true);
                    life2.SetActive(false);
                    life3.SetActive(false);
                    life4.SetActive(false);
                    life5.SetActive(false);
                    life6.SetActive(false);
                    break;
                case 2:
                    life.SetActive(false);
                    life2.SetActive(true);
                    life3.SetActive(false);
                    life4.SetActive(false);
                    life5.SetActive(false);
                    life6.SetActive(false);
                    break;
                case 3:
                    life.SetActive(false);
                    life2.SetActive(false);
                    life3.SetActive(true);
                    life4.SetActive(false);
                    life5.SetActive(false);
                    life6.SetActive(false);
                    break;
                case 4:
                    life.SetActive(false);
                    life2.SetActive(false);
                    life3.SetActive(false);
                    life4.SetActive(true);
                    life5.SetActive(false);
                    life6.SetActive(false);
                    break;
                case 5:
                    life.SetActive(false);
                    life2.SetActive(false);
                    life3.SetActive(false);
                    life4.SetActive(false);
                    life5.SetActive(true);
                    life6.SetActive(false);
                    break;
                case 6:
                    life.SetActive(false);
                    life2.SetActive(false);
                    life3.SetActive(false);
                    life4.SetActive(false);
                    life5.SetActive(false);
                    life6.SetActive(true);
                    break;
                default:
                    life.SetActive(false);
                    life2.SetActive(false);
                    life3.SetActive(false);
                    life4.SetActive(false);
                    life5.SetActive(false);
                    life6.SetActive(false);
                    break;
            }

            healthChange = false;
        }
    }

    /**
     * Collisions with Enemies and Collectibles and if the player lands on the ground
     * Enemies and jumping added by Evan Sinasac, Thursday December 6, 2018
     * Collectibles added by Matthew Pizzo, Wednesday December 12, 2018
     * */
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == 8)
        {
            jump = true;
        }
        Debug.Log("Collision: " + collision.gameObject.tag);
        if(collision.gameObject.layer == 9)
        {
            if (transform.position.y > collision.gameObject.transform.position.y)
            {
                Destroy(collision.gameObject);
                rb.AddForce(new Vector3(0, 3f, 0) * speed);
                enemiesKilled++;
            } else if (transform.position.x < collision.gameObject.transform.position.x)
            {
                health--;
                rb.AddForce(-2f, 1f, 0, ForceMode.Impulse);
                healthChange = true;

            } else if (transform.position.x > collision.gameObject.transform.position.x)
            {
                health--;
                rb.AddForce(2f, 1f, 0, ForceMode.Impulse);
                healthChange = true;

            }
        }

        if (collision.gameObject.layer == 13)
        {
            PlayerPrefs.SetInt("Collectables", PlayerPrefs.GetInt("Collectables") + 1);
            Destroy(collision.gameObject);
        }


        if (collision.gameObject.layer == 11)
        {
            health--;
            healthChange = true;
            Destroy(collision.gameObject);
        }

    }

    /**
     * The player loses health if they are hit by the Mystical Boom Boom Blob's explosion
     * Added by Evan Sinasc, Sunday December 9, 2018
     * */
    private void OnParticleCollision(GameObject other)
    {
        health--;
        healthChange = true;
    }

    /**
     * The sphere collider which controls the two power-ups Fshield and Eshield 
     * */
    private void OnTriggerEnter(Collider collision) //Shield Power-Ups
    {
        if (collision.gameObject.layer == 9 && Fshield == true)
        {
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.layer == 9 && Eshield == true)
        {
            collision.gameObject.GetComponent<Rigidbody>().AddForce(new Vector3(15,15,0) , ForceMode.Impulse);
        }

    }

}
