﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectables : MonoBehaviour
{

    // Use this for initialization

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(new Vector3(0f, 20f, 0f) * Time.deltaTime);

    }

    private void OnTriggerEnter(Collider col)
    {
        if (col.GetComponent<MovePlayer>() != null)
        {

            gameObject.SetActive(false);

        }
    }
}
