﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generation : MonoBehaviour {

    public GameObject endZone;
    public GameObject[] powerups;
    public GameObject[] enemies;
    public GameObject[] platforms;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
