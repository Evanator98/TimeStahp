Evan Sinasac - 104571345
Matthew Pizzo - 104613016
03-60-377 Game Design, Development and Tools
Submission of Final Project - Time Stahp

Submitted folder is the Unity folder with this documentation inside it as well.
It is one extra folder deep because of the naming convention required for submissions.

Game Controls:
This game is controlled with the mouse and WASD keys.  
You use A and D to move left and right.
When you have collected a Laser or Teleport powerup you can click the screen to use it.
You can jump and double jump with space bar.
Pressing and holding left CTRL allows you to run faster.

Ovbjective:
OH NO!  The Evile Krow just stole Kitty Kat's lunch!  Help them traverse this dangerous city
and catch up with Krow to get their lunch back.  Jump into the magic portal at the end of each
level to get closer to Krow!  Collect enough coins for a special bonus!
(Disclaimer, there is no special bonus for collecting coins, but you should do it anyways!)